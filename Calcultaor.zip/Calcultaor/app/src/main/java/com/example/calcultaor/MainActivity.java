package com.example.calcultaor;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;


public class MainActivity extends AppCompatActivity {
    private TextView display;
    private String currentInput = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);
        setButtonListeners();
    }

    private void setButtonListeners() {
        int[] buttonIds = {
                R.id.button0, R.id.button1, R.id.button2, R.id.button3, R.id.button4,
                R.id.button5, R.id.button6, R.id.button7, R.id.button8, R.id.button9,
                R.id.buttonAdd, R.id.buttonSubtract, R.id.buttonMultiply, R.id.buttonDivide,
                R.id.buttonDecimal, R.id.buttonLeftParen, R.id.buttonRightParen
        };

        // Set click listeners for all number and operator buttons
        for (int id : buttonIds) {
            findViewById(id).setOnClickListener(this::onButtonClick);
        }

        findViewById(R.id.buttonEquals).setOnClickListener(this::onEqualsClick);
        findViewById(R.id.buttonClear).setOnClickListener(v -> clear());
        findViewById(R.id.buttonDelete).setOnClickListener(v -> delete());
    }

    private void onButtonClick(View view) {
        Button button = (Button) view;
        currentInput += button.getText().toString();
        display.setText(currentInput);
    }

    private void onEqualsClick(View view) {
        try {
            double result = evaluate(currentInput);
            display.setText(String.valueOf(result));
            currentInput = String.valueOf(result);
        } catch (Exception e) {
            display.setText("Error");
            currentInput = "";
        }
    }

    private void clear() {
        currentInput = "";
        display.setText("0");
    }

    private void delete() {
        if (!currentInput.isEmpty()) {
            currentInput = currentInput.substring(0, currentInput.length() - 1);
            display.setText(currentInput.isEmpty() ? "0" : currentInput);
        }
    }

    private double evaluate(String expression) {
        try {
            Expression exp = new ExpressionBuilder(expression).build();
            return exp.evaluate();
        } catch (Exception e) {
            e.printStackTrace();
            return Double.NaN;
        }
    }

}